// declare module "@zctc/edms-lrs-oauth1.0"
