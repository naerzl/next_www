import LrsFormData from "@zctc/edms-lrs-oauth1.0/formdata"
import { LrsOauth2 } from "@zctc/edms-oauth2.0-npm"

export let formDataInstance = new LrsFormData()

export const lrsOAuth2Instance = new LrsOauth2()
