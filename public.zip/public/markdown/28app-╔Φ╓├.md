## **设置**

第一步：点击“我的”进入个人中心页面，点击设置标识。如图：

![img](/markdown/markdownImg/img134.png) 

 

第二步：进入设置页面可退出登录。如图：

![img](/markdown/markdownImg/img135.png) 