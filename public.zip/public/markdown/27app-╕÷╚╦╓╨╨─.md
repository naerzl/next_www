## **个人中心**

可查看账号绑定的项目信息。

 

第一步：点击“我的”进入个人中心页面。如图：

![img](/markdown/markdownImg/img132.png) 

 

第二步：查看相关信息。如图：

![img](/markdown/markdownImg/img133.png) 